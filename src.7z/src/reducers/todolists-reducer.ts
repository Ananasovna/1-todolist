import {TodoListType} from "../App";
import {v1} from "uuid";

export type RemoveTodoListActionType = {
    type: "REMOVE-TODOLIST"
    todoListId: string
}

export type AddTodoListActionType = {
    type: "ADD-TODOLIST"
    title: string
    todoListId: string
}

export type ChangeTodoListTitleActionType = {
    type: "CHANGE_TODOLIST_TITLE"
    title: string
    todoListId: string
}

export type ActionType = RemoveTodoListActionType | AddTodoListActionType | ChangeTodoListTitleActionType

export const todolistsReducer = (todoLists: TodoListType[], action: ActionType): TodoListType[] => {

    switch (action.type) {
        case "REMOVE-TODOLIST":
            return todoLists.filter(tl => tl.id !== action.todoListId);
        case "ADD-TODOLIST":
            return [...todoLists, {id: action.todoListId, title: action.title, filter: "all"}]
        default:
            return todoLists
    }


}